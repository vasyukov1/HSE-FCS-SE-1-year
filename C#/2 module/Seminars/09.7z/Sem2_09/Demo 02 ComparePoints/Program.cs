﻿  
public struct PointS
    {   // "точка на плоскости" 
        double x, y;
        public double X { get { return x; } set { x = value; } }
        public double Y { get { return y; } set { y = value; } }
        public PointS(double a, double b) { x = a; y = b; }
        public double Distance(PointS ps)
        { // расстояние между точками
            double dx = x - ps.X;
            double dy = y - ps.Y;
            return Math.Sqrt(dx * dx + dy * dy);
        }
    } // end of PointS
public struct CircleS : IComparable
{     // композиция структур
    PointS center;      // центр круга
    double rad;         // радиус круга
    public CircleS(double xc, double yc, double rad)
    {
        center = new PointS(xc, yc);
        this.rad = rad;
    }
    // Свойcтво для центра окружности:
    public PointS Center
    {
        get { return center; }
        set { center = value; }
    }
    // свойство для радиуса окружности:
    public double Rad
    {
        get { return rad; }
        set { rad = value; }
    }
    // свойство для получения значения длины окружности: 
    public double Len { get { return 2 * rad * Math.PI; } }

    public int CompareTo(object? obj)
    {
        throw new NotImplementedException();
    }
}
   

   