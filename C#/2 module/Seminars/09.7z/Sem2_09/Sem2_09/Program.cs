﻿using System;
using System.Diagnostics;

class TestClass : IComparable
{ // тестовый класс
    public int X { get; set; }

    public int CompareTo(object another)
    {
        if (this.X > ((TestClass)another).X) return 1;
        else if (this.X < ((TestClass)another).X) return -1;
        return 0;
    }
}
struct TestStruct : IComparable
{ // тестовая структура
    public int x;
    public int CompareTo(object another)
    {
        if (this.x > ((TestStruct)another).x) return 1;
        else if (this.x < ((TestStruct)another).x) return -1;
        return 0;
    }
}
class Program
{
    public static Random rnd = new Random();
    private const int N = 100000;

    public static void PrintTime(TimeSpan timesp)
    {
        Console.Write("Struct/Class ");

        string elapsedTime = String.Format("{0:00}:{1:00}:{2:00}.{3:00}",
                  timesp.Hours, timesp.Minutes, timesp.Seconds,
                  timesp.Milliseconds / 10);
        Console.WriteLine("RunTime " + elapsedTime);
    }
    static void Main(string[] args)
    {
        TestClass[] tc = new TestClass[N]; //массивы тесового класса и структуры
        TestStruct[] ts = new TestStruct[N];
        for (int i = 0; i < N; i++)
        {
            tc[i] = new TestClass();
            int tmp = rnd.Next();
            tc[i].X = tmp;
            ts[i].x = tmp;
        }
        Stopwatch sw = new Stopwatch(); // замеряем время
        sw.Start();
        Array.Sort(ts); // сортируем массив структур
        sw.Stop();
        PrintTime(sw.Elapsed); // запускает событие каждые 2 с

        sw.Restart();
        Array.Sort(tc); // сортируем массив ссылок на объекты
        sw.Stop();
        PrintTime(sw.Elapsed);
        Console.ReadLine();
    }

}
